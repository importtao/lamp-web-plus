import{d as m,r as a,n as u,p as e,aF as f,aW as b,L as s,aX as v,o as h}from"./index.b361f078.js";import{R as i}from"./index.3b2ad637.js";import{D as n}from"./index.b3908db1.js";import"./vendor.352e3120.js";import"./responsiveObserve.16e475dd.js";var d=m({components:{[i.name]:i,[n.name]:n,[n.Item.name]:n.Item},emits:["redo"],setup(_,{emit:c}){return{redo:()=>{c("redo")}}}}),T=`.step3[data-v-d60ef3fa] {
  width: 600px;
  margin: 0 auto;
}
.desc-wrap[data-v-d60ef3fa] {
  padding: 24px 40px;
  margin-top: 24px;
  background: #fafafa;
}`;const t=f();b("data-v-d60ef3fa");const x={class:"step3"},I=s(" \u518D\u8F6C\u4E00\u7B14 "),g=s(" \u67E5\u770B\u8D26\u5355 "),j={class:"desc-wrap"},k=s(" ant-design@alipay.com "),w=s(" test@example.com "),y=s(" Vben "),C=s(" 500\u5143 ");v();const S=t((_,c,$,V,B,D)=>{const p=a("a-button"),r=a("a-result"),o=a("a-descriptions-item"),l=a("a-descriptions");return h(),u("div",x,[e(r,{status:"success",title:"\u64CD\u4F5C\u6210\u529F","sub-title":"\u9884\u8BA1\u4E24\u5C0F\u65F6\u5185\u5230\u8D26"},{extra:t(()=>[e(p,{type:"primary",onClick:_.redo},{default:t(()=>[I]),_:1},8,["onClick"]),e(p,null,{default:t(()=>[g]),_:1})]),_:1}),e("div",j,[e(l,{column:1,class:"mt-5"},{default:t(()=>[e(o,{label:"\u4ED8\u6B3E\u8D26\u6237"},{default:t(()=>[k]),_:1}),e(o,{label:"\u6536\u6B3E\u8D26\u6237"},{default:t(()=>[w]),_:1}),e(o,{label:"\u6536\u6B3E\u4EBA\u59D3\u540D"},{default:t(()=>[y]),_:1}),e(o,{label:"\u8F6C\u8D26\u91D1\u989D"},{default:t(()=>[C]),_:1})]),_:1})])])});d.render=S,d.__scopeId="data-v-d60ef3fa";export default d;
