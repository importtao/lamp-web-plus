import p from"./TargetContent.c6525c68.js";import{d,ep as c,bC as m,r as n,o as _,n as l,J as t,p as e}from"./index.b361f078.js";import{_ as f}from"./PageWrapper.3df1718a.js";import"./index.a4d5d3e5.js";import"./index.6ea0a64b.js";import"./UpOutlined.cbb592c6.js";import"./PlusOutlined.e0fec5ea.js";import"./index.6cab1e04.js";import"./Col.4346c2f2.js";import"./responsiveObserve.16e475dd.js";import"./canUseDom.0bf35682.js";import"./vendor.352e3120.js";import"./usePageContext.48026c97.js";import"./onMountedOrActivated.db240d29.js";import"./index.2682bd6c.js";import"./index.ad62d489.js";import"./useBreakpoint.3b9cff8d.js";import"./useSize.5dcbe36a.js";import"./transButton.7b09546d.js";import"./ArrowLeftOutlined.9183eb3a.js";var o=d({components:{LazyContainer:c,PageWrapper:f,TargetContent:p,Skeleton:m}}),G=`.lazy-base-demo-wrap {
  display: flex;
  width: 50%;
  height: 2000px;
  margin: 20px auto;
  text-align: center;
  background: #fff;
  justify-content: center;
  flex-direction: column;
  align-items: center;
}
.lazy-base-demo-box {
  width: 300px;
  height: 300px;
}
.lazy-base-demo h1 {
  height: 1300px;
  margin: 20px 0;
}`;const u={class:"lazy-base-demo-wrap"},x=e("h1",null,"\u5411\u4E0B\u6EDA\u52A8",-1),b={class:"lazy-base-demo-box"};function j(g,h,C,y,v,z){const a=n("TargetContent"),s=n("Skeleton"),r=n("LazyContainer"),i=n("PageWrapper");return _(),l(i,{title:"\u61D2\u52A0\u8F7D\u57FA\u7840\u793A\u4F8B",content:"\u5411\u4E0B\u6EDA\u52A8\u5230\u53EF\u89C1\u533A\u57DF\u624D\u4F1A\u52A0\u8F7D\u7EC4\u4EF6"},{default:t(()=>[e("div",u,[x,e("div",b,[e(r,null,{skeleton:t(()=>[e(s,{rows:10})]),default:t(()=>[e(a)]),_:1})])])]),_:1})}o.render=j;export default o;
