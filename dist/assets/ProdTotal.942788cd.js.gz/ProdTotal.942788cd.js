import{w as b}from"./data.aa527d47.js";import{d as v,r as d,o as a,n as o,M as u,aE as g,p as n,q as p,aF as f}from"./index.b361f078.js";import{R as i,C as l}from"./index.6cab1e04.js";import"./vendor.352e3120.js";import"./Col.4346c2f2.js";import"./responsiveObserve.16e475dd.js";import"./canUseDom.0bf35682.js";var e=v({components:{[i.name]:i,[l.name]:l},setup(){return{wokbProd:b}}}),A=`.prod-total[data-v-72749e4b] {
  padding: 12px 4px 12px 12px;
  background: #fff;
}
.prod-total__item[data-v-72749e4b] {
  display: inline-block;
  flex: 0 0 calc(25% - 8px);
  padding: 20px 10px;
  margin-right: 8px;
  border-radius: 4px;
}
.prod-total__item span[data-v-72749e4b] {
  font-size: 14px;
  line-height: 28px;
}
.prod-total__item div[data-v-72749e4b] {
  font-size: 26px;
}
.prod-total__item .img[data-v-72749e4b] {
  float: left;
  width: 62px;
  height: 62px;
}
.prod-total__item-0[data-v-72749e4b] {
  background: rgba(254, 97, 178, 0.1);
}
.prod-total__item-0-img[data-v-72749e4b] {
  background: url(__VITE_ASSET__9d43b287__) no-repeat;
}
.prod-total__item-0 div[data-v-72749e4b] {
  color: #fe61b2;
}
.prod-total__item-1[data-v-72749e4b] {
  background: rgba(254, 163, 64, 0.1);
}
.prod-total__item-1-img[data-v-72749e4b] {
  background: url(__VITE_ASSET__b82e500d__) no-repeat;
}
.prod-total__item-1 div[data-v-72749e4b] {
  color: #fea340;
}
.prod-total__item-2[data-v-72749e4b] {
  background: rgba(172, 70, 255, 0.1);
}
.prod-total__item-2-img[data-v-72749e4b] {
  background: url(__VITE_ASSET__285ce27a__) no-repeat;
}
.prod-total__item-2 div[data-v-72749e4b] {
  color: #9e55ff;
}
.prod-total__item-3[data-v-72749e4b] {
  background: rgba(0, 196, 186, 0.1);
}
.prod-total__item-3-img[data-v-72749e4b] {
  background: url(__VITE_ASSET__d4b1ec50__) no-repeat;
}
.prod-total__item-3 div[data-v-72749e4b] {
  color: #00c4ba;
}`;const r=f(),x=r((s,k,S,h,w,E)=>{const m=d("a-col"),c=d("a-row");return a(),o(c,{class:"prod-total"},{default:r(()=>[(a(!0),o(u,null,g(s.wokbProd,(t,_)=>(a(),o(m,{key:t.type,xs:12,sm:6,class:["prod-total__item",`prod-total__item-${_}`]},{default:r(()=>[n("div",{class:["img",`prod-total__item-${_}-img`]},null,2),n("div",null,p(t.amount),1),n("span",null,p(t.type),1)]),_:2},1032,["class"]))),128))]),_:1})});e.render=x,e.__scopeId="data-v-72749e4b";export default e;
