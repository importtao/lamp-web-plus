import{projectList as x}from"./data.e00c2600.js";import{d as C,r as n,n as r,J as o,o as a,p as t,M as v,aE as b,q as c}from"./index.0523a5a3.js";import{L as i}from"./index.c860e084.js";import{C as L}from"./index.a91ea070.js";import{R as p,C as d}from"./index.4637d8b2.js";import"./vendor.352e3120.js";import"./Col.102f0df6.js";import"./responsiveObserve.43c11602.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.a9fc3198.js";import"./index.08635ac9.js";import"./UpOutlined.a2803449.js";import"./PlusOutlined.3cbe2bbe.js";var h="/lamp-web-plus/assets/demo.f132a062.png",l=C({components:{List:i,ListItem:i.Item,Card:L,[p.name]:p,[d.name]:d},setup(){return{prefixCls:"account-center-project",list:x,demoImg:h}}}),V=`.account-center-project__card {
  width: 100%;
}
.account-center-project__card .ant-card-body {
  padding: 0 0 24px 0;
}
.account-center-project__card img {
  width: 100%;
  height: 130px;
}
.account-center-project__card-title {
  margin: 5px 10px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.account-center-project__card-content {
  margin: 5px 10px;
}`;function w(e,$,I,y,k,B){const m=n("Card"),_=n("ListItem"),u=n("a-col"),f=n("a-row"),j=n("List");return a(),r(j,{class:e.prefixCls},{default:o(()=>[t(f,{gutter:16},{default:o(()=>[(a(!0),r(v,null,b(e.list,(s,g)=>(a(),r(u,{key:g,span:6},{default:o(()=>[t(_,null,{default:o(()=>[t(m,{hoverable:!0,class:`${e.prefixCls}__card`},{default:o(()=>[t("img",{src:e.demoImg},null,8,["src"]),t("div",{class:`${e.prefixCls}__card-title`},c(s.title),3),t("div",{class:`${e.prefixCls}__card-content`},c(s.content),3)]),_:2},1032,["class"])]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1},8,["class"])}l.render=w;export default l;
