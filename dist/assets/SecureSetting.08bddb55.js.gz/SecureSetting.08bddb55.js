import{d as f,aY as u,r as a,n as o,p as n,M as v,aE as I,aF as L,aW as x,aX as g,o as s,L as C,q as r,N as b}from"./index.f012a3f4.js";import{a as h}from"./data.a32591d5.js";import{L as i}from"./index.a3803284.js";import"./vendor.352e3120.js";import"./Col.13d8b9cb.js";import"./responsiveObserve.40f9db24.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.521f32f2.js";var p=f({components:{CollapseContainer:u,List:i,ListItem:i.Item,ListItemMeta:i.Item.Meta},setup(){return{list:h}}}),T=`.extra[data-v-1bfa2029] {
  float: right;
  margin-top: 10px;
  margin-right: 30px;
  font-weight: normal;
  color: #1890ff;
  cursor: pointer;
}`;const e=L();x("data-v-1bfa2029");const j={key:0,class:"extra"};g();const S=e((c,k,y,M,$,N)=>{const d=a("ListItemMeta"),l=a("ListItem"),_=a("List"),m=a("CollapseContainer");return s(),o(m,{title:"\u5B89\u5168\u8BBE\u7F6E",canExpan:!1},{default:e(()=>[n(_,null,{default:e(()=>[(s(!0),o(v,null,I(c.list,t=>(s(),o(l,{key:t.key},{default:e(()=>[n(d,null,{title:e(()=>[C(r(t.title)+" ",1),t.extra?(s(),o("div",j,r(t.extra),1)):b("",!0)]),description:e(()=>[n("div",null,r(t.description),1)]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1})});p.render=S,p.__scopeId="data-v-1bfa2029";export default p;
