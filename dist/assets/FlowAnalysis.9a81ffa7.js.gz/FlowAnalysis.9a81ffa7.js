import{d as t,p as n,M as r,aY as i,L as a}from"./index.f012a3f4.js";import f from"./TrendLine.7b1ea54e.js";import{T as s}from"./index.fb19caf5.js";import{R as p,C as o}from"./index.41a9c009.js";import{P as u}from"./index.ccba4a8f.js";import{D as d}from"./index.a99c15a9.js";import"./vendor.352e3120.js";import"./useECharts.79e93ca8.js";import"./props.f48aca0b.js";import"./UpOutlined.5f7f87c9.js";import"./PlusOutlined.0c40939d.js";import"./Col.13d8b9cb.js";import"./responsiveObserve.40f9db24.js";import"./canUseDom.0bf35682.js";var P=`.flow-analysis {
  width: 100%;
  background: #fff;
}
.flow-analysis__left {
  padding: 10px 20px !important;
  border-right: 1px solid rgba(0, 0, 0, 0.06);
  border-radius: 0;
}
.flow-analysis__score {
  margin-top: 20px;
  font-size: 30px;
  line-height: 38px;
  color: rgba(0, 0, 0, 0.85);
}
.flow-analysis__score span {
  font-size: 20px;
  line-height: 28px;
  color: rgba(0, 0, 0, 0.85);
}
.flow-analysis__rank {
  margin: 16px 0;
  font-size: 12px;
  line-height: 20px;
  color: #7c8087;
}
.flow-analysis__rank span {
  display: inline-block;
  margin-left: 10px;
  color: #1c1d21;
}
.flow-analysis__rs li {
  display: flex;
  line-height: 28px;
  justify-content: space-between;
}
.flow-analysis__rs li span:nth-child(1) {
  font-size: 14px;
  color: #1c1d21;
}
.flow-analysis__rs li span:nth-child(2) {
  font-size: 16px;
  color: #1c1d21;
}`;const l="flow-analysis";var c=t({name:"AnalysisFLow",setup(){const e=()=>n(p,null,{default:()=>n(r,null,[n(o,{md:24,lg:8},{default:()=>n(i,{title:"\u6574\u4F53\u6D41\u91CF\u8BC4\u5206",canExpan:!1,class:`${l}__left`},{default:()=>n("div",null,[n("div",{class:`${l}__score`},[a("86.2"),n("span",null,[a("\u5206")])]),n("div",{class:`${l}__rank`},[a("\u6392\u540D"),n("span",null,[a("\u524D20%")])]),n(u,{percent:70,showInfo:!1,status:"active"},null),n(d,null,null),n("ul",{class:`${l}__rs`},[n("li",null,[n("span",null,[a("\u5E73\u5747\u5206")]),n("span",null,[a("77.5")])]),n("li",null,[n("span",null,[a("\u6700\u9AD8\u5206")]),n("span",null,[a("99.5")])]),n("li",null,[n("span",null,[a("\u6700\u4F4E\u5206")]),n("span",null,[a("56.5")])])])])})}),n(o,{md:24,lg:16},{default:()=>n(i,{title:"\u6574\u4F53\u6D41\u91CF\u8D8B\u52BF",canExpan:!1},{default:()=>n(f,null,null)})})])});return()=>n(s,{class:l,"default-active-key":"1"},{default:()=>[n(s.TabPane,{key:"1",tab:"\u4EA7\u54C1\u4E00"},{default:()=>e()}),n(s.TabPane,{key:"2",tab:"\u4EA7\u54C1\u4E8C"},{default:()=>e()}),n(s.TabPane,{key:"3",tab:"\u4EA7\u54C1\u4E09"},{default:()=>e()})]})}});export default c;
