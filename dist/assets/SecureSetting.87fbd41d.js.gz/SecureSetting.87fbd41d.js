import{d as f,aY as u,r as a,n as o,p as n,M as v,aE as I,aF as L,aW as x,aX as g,o as s,L as C,q as r,N as h}from"./index.0523a5a3.js";import{a as j}from"./data.a32591d5.js";import{L as i}from"./index.c860e084.js";import"./vendor.352e3120.js";import"./Col.102f0df6.js";import"./responsiveObserve.43c11602.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.a9fc3198.js";var p=f({components:{CollapseContainer:u,List:i,ListItem:i.Item,ListItemMeta:i.Item.Meta},setup(){return{list:j}}}),T=`.extra[data-v-1bfa2029] {
  float: right;
  margin-top: 10px;
  margin-right: 30px;
  font-weight: normal;
  color: #1890ff;
  cursor: pointer;
}`;const e=L();x("data-v-1bfa2029");const S={key:0,class:"extra"};g();const k=e((c,y,b,M,$,N)=>{const l=a("ListItemMeta"),d=a("ListItem"),_=a("List"),m=a("CollapseContainer");return s(),o(m,{title:"\u5B89\u5168\u8BBE\u7F6E",canExpan:!1},{default:e(()=>[n(_,null,{default:e(()=>[(s(!0),o(v,null,I(c.list,t=>(s(),o(d,{key:t.key},{default:e(()=>[n(l,null,{title:e(()=>[C(r(t.title)+" ",1),t.extra?(s(),o("div",S,r(t.extra),1)):h("",!0)]),description:e(()=>[n("div",null,r(t.description),1)]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1})});p.render=k,p.__scopeId="data-v-1bfa2029";export default p;
