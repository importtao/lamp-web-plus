import{projectList as x}from"./data.35d44565.js";import{d as C,r as n,n as r,J as o,o as s,p as t,M as b,aE as v,q as c}from"./index.b361f078.js";import{L as i}from"./index.0635e943.js";import{C as L}from"./index.a4d5d3e5.js";import{R as p,C as d}from"./index.6cab1e04.js";import"./vendor.352e3120.js";import"./Col.4346c2f2.js";import"./responsiveObserve.16e475dd.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.3b9cff8d.js";import"./index.6ea0a64b.js";import"./UpOutlined.cbb592c6.js";import"./PlusOutlined.e0fec5ea.js";var h="/lamp-web-plus/assets/demo.f132a062.png",l=C({components:{List:i,ListItem:i.Item,Card:L,[p.name]:p,[d.name]:d},setup(){return{prefixCls:"account-center-project",list:x,demoImg:h}}}),V=`.account-center-project__card {
  width: 100%;
}
.account-center-project__card .ant-card-body {
  padding: 0 0 24px 0;
}
.account-center-project__card img {
  width: 100%;
  height: 130px;
}
.account-center-project__card-title {
  margin: 5px 10px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.account-center-project__card-content {
  margin: 5px 10px;
}`;function w(e,$,I,y,k,B){const m=n("Card"),_=n("ListItem"),u=n("a-col"),f=n("a-row"),j=n("List");return s(),r(j,{class:e.prefixCls},{default:o(()=>[t(f,{gutter:16},{default:o(()=>[(s(!0),r(b,null,v(e.list,(a,g)=>(s(),r(u,{key:g,span:6},{default:o(()=>[t(_,null,{default:o(()=>[t(m,{hoverable:!0,class:`${e.prefixCls}__card`},{default:o(()=>[t("img",{src:e.demoImg},null,8,["src"]),t("div",{class:`${e.prefixCls}__card-title`},c(a.title),3),t("div",{class:`${e.prefixCls}__card-content`},c(a.content),3)]),_:2},1032,["class"])]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1},8,["class"])}l.render=w;export default l;
