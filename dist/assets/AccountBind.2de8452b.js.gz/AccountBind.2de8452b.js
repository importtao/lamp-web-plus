import{d as x,aY as L,b_ as b,r as a,n,p as s,M as C,aE as j,aF as k,o,N as p,L as l,q as r}from"./index.ff8e7350.js";import{c as y}from"./data.a32591d5.js";import{L as c}from"./index.51a28d34.js";import"./vendor.352e3120.js";import"./Col.1d424bff.js";import"./responsiveObserve.936f38cb.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.549ec32d.js";var i=x({components:{CollapseContainer:L,List:c,ListItem:c.Item,ListItemMeta:c.Item.Meta,Icon:b},setup(){return{list:y}}}),A=`.avatar[data-v-53e6fb4d] {
  font-size: 40px !important;
}
.extra[data-v-53e6fb4d] {
  float: right;
  margin-top: 10px;
  margin-right: 30px;
  cursor: pointer;
}`;const e=k(),g=e((_,$,h,B,M,N)=>{const d=a("Icon"),m=a("a-button"),u=a("ListItemMeta"),f=a("ListItem"),v=a("List"),I=a("CollapseContainer");return o(),n(I,{title:"\u8D26\u53F7\u7ED1\u5B9A",canExpan:!1},{default:e(()=>[s(v,null,{default:e(()=>[(o(!0),n(C,null,j(_.list,t=>(o(),n(f,{key:t.key},{default:e(()=>[s(u,null,{avatar:e(()=>[t.avatar?(o(),n(d,{key:0,class:"avatar",icon:t.avatar,color:t.color},null,8,["icon","color"])):p("",!0)]),title:e(()=>[l(r(t.title)+" ",1),t.extra?(o(),n(m,{key:0,type:"link",size:"small",class:"extra"},{default:e(()=>[l(r(t.extra),1)]),_:2},1024)):p("",!0)]),description:e(()=>[s("div",null,r(t.description),1)]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1})});i.render=g,i.__scopeId="data-v-53e6fb4d";export default i;
