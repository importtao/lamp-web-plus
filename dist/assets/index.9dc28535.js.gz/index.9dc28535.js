import{d as _,d7 as d,r as e,n as i,p as t,aF as l,aW as p,L as o,aX as u,o as m}from"./index.0523a5a3.js";import{R as f}from"./index.60e0ef00.js";import"./vendor.352e3120.js";var s=_({components:{Result:f,CloseCircleOutlined:d}}),L=`.result-error[data-v-cd846a08] {
  padding: 48px 32px;
  background: #fff;
}
.result-error__content[data-v-cd846a08] {
  padding: 24px 40px;
  background: #fafafa;
}
.result-error__content-title[data-v-cd846a08] {
  margin-bottom: 16px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.result-error__content-icon[data-v-cd846a08] {
  color: #ff4d4f;
}`;const n=l();p("data-v-cd846a08");const v={class:"m-5 result-error"},h=o(" \u8FD4\u56DE\u4FEE\u6539 "),x={class:"result-error__content"},b=t("div",{class:"result-error__content-title"}," \u60A8\u63D0\u4EA4\u7684\u5185\u5BB9\u6709\u5982\u4E0B\u9519\u8BEF\uFF1A ",-1),g={class:"mb-4"},C=o(" \u60A8\u7684\u8D26\u6237\u5DF2\u88AB\u51BB\u7ED3 "),k=t("a",{class:"ml-4"},"\u7ACB\u5373\u89E3\u51BB >",-1),y={class:"mb-4"},I=o(" \u60A8\u7684\u8D26\u6237\u8FD8\u4E0D\u5177\u5907\u7533\u8BF7\u8D44\u683C "),R=t("a",{class:"ml-4"},"\u7ACB\u5373\u89E3\u51BB >",-1);u();const $=n((j,w,O,S,B,N)=>{const a=e("a-button"),c=e("Result"),r=e("CloseCircleOutlined");return m(),i("div",v,[t(c,{status:"error",title:"\u63D0\u4EA4\u5931\u8D25","sub-title":"\u8BF7\u6838\u5BF9\u5E76\u4FEE\u6539\u4EE5\u4E0B\u4FE1\u606F\u540E\uFF0C\u518D\u91CD\u65B0\u63D0\u4EA4\u3002"},{extra:n(()=>[t(a,{key:"console",type:"primary"},{default:n(()=>[h]),_:1})]),_:1}),t("div",x,[b,t("div",g,[t(r,{class:"mr-2 result-error__content-icon"}),C,k]),t("div",y,[t(r,{class:"mr-2 result-error__content-icon"}),I,R])])])});s.render=$,s.__scopeId="data-v-cd846a08";export default s;
