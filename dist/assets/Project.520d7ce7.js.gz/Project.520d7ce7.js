import{projectList as x}from"./data.2163dd7b.js";import{d as C,r as n,n as r,J as o,o as a,p as t,M as v,aE as b,q as c}from"./index.f012a3f4.js";import{L as i}from"./index.a3803284.js";import{C as L}from"./index.126f0ac9.js";import{R as p,C as d}from"./index.41a9c009.js";import"./vendor.352e3120.js";import"./Col.13d8b9cb.js";import"./responsiveObserve.40f9db24.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.521f32f2.js";import"./index.fb19caf5.js";import"./UpOutlined.5f7f87c9.js";import"./PlusOutlined.0c40939d.js";var h="/lamp/assets/demo.f132a062.png",l=C({components:{List:i,ListItem:i.Item,Card:L,[p.name]:p,[d.name]:d},setup(){return{prefixCls:"account-center-project",list:x,demoImg:h}}}),V=`.account-center-project__card {
  width: 100%;
}
.account-center-project__card .ant-card-body {
  padding: 0 0 24px 0;
}
.account-center-project__card img {
  width: 100%;
  height: 130px;
}
.account-center-project__card-title {
  margin: 5px 10px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.account-center-project__card-content {
  margin: 5px 10px;
}`;function w(e,$,I,y,k,B){const m=n("Card"),_=n("ListItem"),f=n("a-col"),u=n("a-row"),j=n("List");return a(),r(j,{class:e.prefixCls},{default:o(()=>[t(u,{gutter:16},{default:o(()=>[(a(!0),r(v,null,b(e.list,(s,g)=>(a(),r(f,{key:g,span:6},{default:o(()=>[t(_,null,{default:o(()=>[t(m,{hoverable:!0,class:`${e.prefixCls}__card`},{default:o(()=>[t("img",{src:e.demoImg},null,8,["src"]),t("div",{class:`${e.prefixCls}__card-title`},c(s.title),3),t("div",{class:`${e.prefixCls}__card-content`},c(s.content),3)]),_:2},1032,["class"])]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1},8,["class"])}l.render=w;export default l;
