import{d as C,b_ as h,r as t,n as r,p as a,M as $,aE as I,aF as k,aW as w,L as p,aX as y,o as i,N as S,q as V}from"./index.b361f078.js";import{cardList as L}from"./data.6718297b.js";import{_ as N}from"./PageWrapper.3df1718a.js";import{C as l}from"./index.a4d5d3e5.js";import{L as c}from"./index.0635e943.js";import{R as _,C as m}from"./index.6cab1e04.js";import"./vendor.352e3120.js";import"./usePageContext.48026c97.js";import"./onMountedOrActivated.db240d29.js";import"./index.2682bd6c.js";import"./index.ad62d489.js";import"./useBreakpoint.3b9cff8d.js";import"./responsiveObserve.16e475dd.js";import"./useSize.5dcbe36a.js";import"./transButton.7b09546d.js";import"./ArrowLeftOutlined.9183eb3a.js";import"./index.6ea0a64b.js";import"./UpOutlined.cbb592c6.js";import"./PlusOutlined.e0fec5ea.js";import"./Col.4346c2f2.js";import"./canUseDom.0bf35682.js";var d=C({components:{Icon:h,PageWrapper:N,[l.name]:l,[c.name]:c,[c.Item.name]:c.Item,[_.name]:_,[m.name]:m},setup(){return{prefixCls:"list-card",list:L}}}),da=`.list-card__link[data-v-7aac9e1e] {
  margin-top: 10px;
  font-size: 14px;
}
.list-card__link a[data-v-7aac9e1e] {
  margin-right: 30px;
}
.list-card__link span[data-v-7aac9e1e] {
  margin-left: 5px;
}
.list-card__card[data-v-7aac9e1e] {
  width: 100%;
  margin-bottom: -8px;
}
.list-card__card .ant-card-body[data-v-7aac9e1e] {
  padding: 16px;
}
.list-card__card-title[data-v-7aac9e1e] {
  margin-bottom: 5px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.list-card__card-title .icon[data-v-7aac9e1e] {
  margin-top: -5px;
  margin-right: 10px;
  font-size: 38px !important;
}
.list-card__card-detail[data-v-7aac9e1e] {
  padding-top: 10px;
  padding-left: 30px;
  font-size: 14px;
  color: rgba(0, 0, 0, 0.5);
}`;const e=k();w("data-v-7aac9e1e");const P=p(" \u57FA\u4E8EVue Next, TypeScript, Ant Design Vue\u5B9E\u73B0\u7684\u4E00\u5957\u5B8C\u6574\u7684\u4F01\u4E1A\u7EA7\u540E\u53F0\u7BA1\u7406\u7CFB\u7EDF\u3002 "),z=a("span",null,"\u5F00\u59CB",-1),O=a("span",null,"\u7B80\u4ECB",-1),W=a("span",null,"\u6587\u6863",-1);y();const A=e((n,B,D,T,F,M)=>{const o=t("Icon"),f=t("a-card"),u=t("a-list-item"),x=t("a-col"),g=t("a-row"),b=t("a-list"),v=t("PageWrapper");return i(),r(v,{class:n.prefixCls,title:"\u5361\u7247\u5217\u8868"},{headerContent:e(()=>[P,a("div",{class:`${n.prefixCls}__link`},[a("a",null,[a(o,{icon:"bx:bx-paper-plane",color:"#1890ff"}),z]),a("a",null,[a(o,{icon:"carbon:warning",color:"#1890ff"}),O]),a("a",null,[a(o,{icon:"ion:document-text-outline",color:"#1890ff"}),W])],2)]),default:e(()=>[a("div",{class:`${n.prefixCls}__content`},[a(b,null,{default:e(()=>[a(g,{gutter:16},{default:e(()=>[(i(!0),r($,null,I(n.list,(s,j)=>(i(),r(x,{key:j,span:6},{default:e(()=>[a(u,null,{default:e(()=>[a(f,{hoverable:!0,class:`${n.prefixCls}__card`},{default:e(()=>[a("div",{class:`${n.prefixCls}__card-title`},[s.icon?(i(),r(o,{key:0,class:"icon",icon:s.icon,color:s.color},null,8,["icon","color"])):S("",!0),p(" "+V(s.title),1)],2),a("div",{class:`${n.prefixCls}__card-detail`}," \u57FA\u4E8EVue Next, TypeScript, Ant Design Vue\u5B9E\u73B0\u7684\u4E00\u5957\u5B8C\u6574\u7684\u4F01\u4E1A\u7EA7\u540E\u53F0\u7BA1\u7406\u7CFB\u7EDF ",2)]),_:2},1032,["class"])]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1})],2)]),_:1},8,["class"])});d.render=A,d.__scopeId="data-v-7aac9e1e";export default d;
