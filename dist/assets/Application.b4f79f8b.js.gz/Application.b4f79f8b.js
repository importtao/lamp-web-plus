import{d as v,b_ as h,r as a,n as e,J as c,o as s,p as o,M as w,aE as L,N as p,L as r,q as i}from"./index.b6dfbfcf.js";import{applicationList as $}from"./data.b49d8f11.js";import{L as d}from"./index.5c3ef301.js";import{C as y}from"./index.4d2d1116.js";import{R as _,C as m}from"./index.fc5361f4.js";import"./vendor.352e3120.js";import"./Col.590da3fb.js";import"./responsiveObserve.7206f913.js";import"./canUseDom.0bf35682.js";import"./useBreakpoint.4a44e358.js";import"./index.d98a3c80.js";import"./UpOutlined.4269b743.js";import"./PlusOutlined.84d8b58b.js";var f=v({components:{List:d,ListItem:d.Item,Card:y,Icon:h,[_.name]:_,[m.name]:m},setup(){return{prefixCls:"account-center-application",list:$}}}),Q=`.account-center-application__card {
  width: 100%;
  margin-bottom: -12px;
}
.account-center-application__card .ant-card-body {
  padding: 16px;
}
.account-center-application__card-title {
  margin-bottom: 5px;
  font-size: 16px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
}
.account-center-application__card-title .icon {
  margin-top: -5px;
  font-size: 22px;
}
.account-center-application__card-num {
  margin-left: 24px;
  line-height: 36px;
  color: #7d7a7a;
}
.account-center-application__card-num span {
  margin-left: 5px;
  font-size: 18px;
  color: #000;
}
.account-center-application__card-download {
  float: right;
  font-size: 20px !important;
  color: #1890ff;
}`;const I=r(" \u6D3B\u8DC3\u7528\u6237\uFF1A"),k=r(" \u4E07 "),z=r(" \u65B0\u589E\u7528\u6237\uFF1A");function N(t,B,O,V,D,R){const l=a("Icon"),u=a("Card"),x=a("ListItem"),C=a("a-col"),b=a("a-row"),g=a("List");return s(),e(g,{class:t.prefixCls},{default:c(()=>[o(b,{gutter:16},{default:c(()=>[(s(!0),e(w,null,L(t.list,(n,j)=>(s(),e(C,{key:j,span:6},{default:c(()=>[o(x,null,{default:c(()=>[o(u,{hoverable:!0,class:`${t.prefixCls}__card`},{default:c(()=>[o("div",{class:`${t.prefixCls}__card-title`},[n.icon?(s(),e(l,{key:0,class:"icon",icon:n.icon,color:n.color},null,8,["icon","color"])):p("",!0),r(" "+i(n.title),1)],2),o("div",{class:`${t.prefixCls}__card-num`},[I,o("span",null,i(n.active),1),k],2),o("div",{class:`${t.prefixCls}__card-num`},[z,o("span",null,i(n.new),1)],2),n.download?(s(),e(l,{key:0,class:`${t.prefixCls}__card-download`,icon:n.download},null,8,["class","icon"])):p("",!0)]),_:2},1032,["class"])]),_:2},1024)]),_:2},1024))),128))]),_:1})]),_:1},8,["class"])}f.render=N;export default f;
